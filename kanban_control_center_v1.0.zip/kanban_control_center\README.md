# 小灵同学助理看板控制中心

## 🎯 项目概述
专为陈先生（czp）开发的主电脑看板控制中心，用于实时查看小灵同学助理工作状态、分配任务和管理工作流程。

## 📋 功能特性

### v1.0 基础版 (今天完成)
- ✅ 实时显示任务状态和进度
- ✅ 查看工作日志和操作记录
- ✅ 添加、编辑、完成任务
- ✅ 一键启动，简单易用

### v1.1 增强版 (本周完成)
- 🔄 实时自动刷新状态
- 🔄 批量操作和任务模板
- 🔄 界面优化和主题切换
- 🔄 快捷键和快速操作

### v1.2 智能版 (本月完成)
- ⏳ 智能任务推荐
- ⏳ 系统集成（日历、邮箱、GitHub）
- ⏳ 移动端同步支持
- ⏳ 数据分析和报告

## 🚀 快速开始

### 启动方式
1. **双击启动**: `start_kanban.bat`
2. **命令行启动**: `python app.py`
3. **系统托盘**: 常驻托盘，点击打开

### 访问地址
- **本地地址**: http://localhost:5000
- **默认端口**: 5000

## 📁 项目结构
```
kanban_control_center/
├── app.py              # Flask主应用
├── start_kanban.bat    # 一键启动脚本
├── requirements.txt    # Python依赖
├── static/            # 静态资源
│   ├── css/
│   ├── js/
│   └── images/
├── templates/         # HTML模板
│   └── index.html
└── README.md          # 本文档
```

## 🔧 技术栈
- **后端**: Python + Flask
- **前端**: HTML5 + CSS3 + JavaScript
- **数据**: JSON文件存储 (与现有tasks.json同步)
- **通信**: REST API + 未来WebSocket

## 📊 数据同步
控制中心与现有工作系统完全同步：
- 实时读取 `C:\Users\czp\openclaw\tasks.json`
- 实时读取 `C:\Users\czp\openclaw\KANBAN.md`
- 实时读取 `C:\Users\czp\openclaw\logs\操作日志-YYYY-MM-DD.md`

## 🎨 界面设计
- **简洁现代** - 清晰的信息展示
- **响应式布局** - 适应不同屏幕
- **直观操作** - 无需学习成本
- **状态可视化** - 颜色编码和进度条

## ⚙️ 配置说明
### 端口配置
如需更改端口，修改 `app.py` 中的端口设置：
```python
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
```

### 数据路径配置
默认使用工作目录，如需更改：
```python
TASKS_FILE = 'C:/Users/czp/openclaw/tasks.json'
KANBAN_FILE = 'C:/Users/czp/openclaw/KANBAN.md'
LOG_DIR = 'C:/Users/czp/openclaw/logs/'
```

## 🔒 安全说明
- **本地运行** - 数据不离开你的电脑
- **无外部依赖** - 无需网络连接
- **权限控制** - 只有本地访问
- **数据备份** - 重要操作自动备份

## 📞 支持与反馈
- **问题报告**: 通过Telegram联系小灵同学助理
- **功能建议**: 随时提出改进意见
- **使用帮助**: 查看界面帮助文档

## 🚀 开发路线图
### 已完成
- ✅ 项目规划和架构设计

### 进行中
- 🔄 v1.0 基础版开发

### 计划中
- ⏳ v1.1 增强版开发
- ⏳ v1.2 智能版开发
- ⏳ 移动端应用开发

---
**版本**: v1.0 基础版
**状态**: 开发中
**预计完成**: 今天下午
**开发者**: 小灵同学助理 🎯