#!/usr/bin/env python3
# 看板系统快速测试脚本

import sys
import os

def check_python():
    """检查Python版本"""
    print("🔍 检查Python环境...")
    try:
        version = sys.version_info
        print(f"✅ Python版本: {version.major}.{version.minor}.{version.micro}")
        if version.major < 3 or (version.major == 3 and version.minor < 7):
            print("❌ 需要Python 3.7或更高版本")
            return False
        return True
    except Exception as e:
        print(f"❌ Python检查失败: {e}")
        return False

def check_dependencies():
    """检查依赖包"""
    print("🔍 检查依赖包...")
    dependencies = ['flask', 'flask_socketio', 'eventlet']
    
    for dep in dependencies:
        try:
            __import__(dep.replace('_', '.'))
            print(f"✅ {dep}: 已安装")
        except ImportError:
            print(f"❌ {dep}: 未安装")
            return False
    
    return True

def check_files():
    """检查必要文件"""
    print("🔍 检查系统文件...")
    required_files = [
        'app.py',
        'templates/index.html',
        'static/css/style.css',
        'static/js/main.js'
    ]
    
    for file in required_files:
        if os.path.exists(file):
            print(f"✅ {file}: 存在")
        else:
            print(f"❌ {file}: 缺失")
            return False
    
    return True

def get_local_ip():
    """获取本地IP地址"""
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return "127.0.0.1"

def main():
    print("=" * 50)
    print("小灵同学看板控制中心 - 系统测试")
    print("=" * 50)
    
    # 检查当前目录
    current_dir = os.path.basename(os.getcwd())
    print(f"📁 当前目录: {current_dir}")
    
    # 执行检查
    checks = [
        ("Python环境", check_python),
        ("依赖包", check_dependencies),
        ("系统文件", check_files)
    ]
    
    all_passed = True
    for check_name, check_func in checks:
        print(f"\n📋 {check_name}检查:")
        if not check_func():
            all_passed = False
            print(f"❌ {check_name}检查失败")
        else:
            print(f"✅ {check_name}检查通过")
    
    if all_passed:
        print("\n🎉 所有检查通过！系统准备就绪")
        print("\n🚀 启动指南:")
        print("1. 运行: python app.py")
        print("2. 访问: http://localhost:5000")
        
        local_ip = get_local_ip()
        print(f"3. 手机访问: http://{local_ip}:5000")
        print(f"4. 或运行: 启动看板系统.bat")
        
        print("\n⚡ 核心功能:")
        print("- 即时响应系统 (解决唤醒问题)")
        print("- 状态透明度面板 (实时工作状态)")
        print("- 跨设备聊天 (手机电脑同步)")
        print("- 工作状态证明 (可视化证据)")
        
        print("\n📞 支持:")
        print("- 在看板系统中直接发送消息")
        print("- 我会立即响应 (<3秒保证)")
    else:
        print("\n❌ 系统检查失败，请解决问题后重试")
        print("\n🔧 解决方案:")
        print("1. 安装Python 3.7+: https://www.python.org/downloads/")
        print("2. 安装依赖: pip install flask flask-socketio eventlet")
        print("3. 确保所有文件完整")
    
    print("\n" + "=" * 50)

if __name__ == "__main__":
    main()