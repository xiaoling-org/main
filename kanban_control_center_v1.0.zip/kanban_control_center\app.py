#!/usr/bin/env python3
"""
小灵同学助理看板控制中心 - Flask应用
版本: v1.0 基础版
功能: 实时查看任务状态、分配任务、管理工作流程
"""

import os
import json
import time
from datetime import datetime, timedelta
from flask import Flask, render_template, jsonify, request, send_from_directory
import threading
import webbrowser
from pathlib import Path

# 初始化Flask应用
app = Flask(__name__, 
            static_folder='static',
            template_folder='templates')

# 配置文件路径
BASE_DIR = Path("C:/Users/czp/openclaw")
TASKS_FILE = BASE_DIR / "tasks.json"
KANBAN_FILE = BASE_DIR / "KANBAN.md"
LOG_DIR = BASE_DIR / "logs"

# 确保目录存在
os.makedirs('static/css', exist_ok=True)
os.makedirs('static/js', exist_ok=True)
os.makedirs('templates', exist_ok=True)

class TaskManager:
    """任务管理器"""
    
    @staticmethod
    def load_tasks():
        """加载任务数据"""
        try:
            if TASKS_FILE.exists():
                with open(TASKS_FILE, 'r', encoding='utf-8') as f:
                    return json.load(f)
            else:
                return {"tasks": [], "stats": {"total": 0, "todo": 0, "in_progress": 0, "done": 0, "ideas": 0}}
        except Exception as e:
            print(f"加载任务数据错误: {e}")
            return {"tasks": [], "stats": {"total": 0, "todo": 0, "in_progress": 0, "done": 0, "ideas": 0}}
    
    @staticmethod
    def save_tasks(data):
        """保存任务数据"""
        try:
            with open(TASKS_FILE, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            print(f"保存任务数据错误: {e}")
            return False
    
    @staticmethod
    def get_task_by_id(task_id):
        """根据ID获取任务"""
        data = TaskManager.load_tasks()
        for task in data.get("tasks", []):
            if task.get("id") == task_id:
                return task
        return None
    
    @staticmethod
    def add_task(task_data):
        """添加新任务"""
        data = TaskManager.load_tasks()
        
        # 生成任务ID
        task_id = f"KB-{len(data['tasks']) + 1:03d}"
        
        # 创建任务对象
        task = {
            "id": task_id,
            "description": task_data.get("description", "新任务"),
            "priority": task_data.get("priority", "medium"),
            "category": task_data.get("category", "general"),
            "status": "todo",
            "created_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
            "started_at": None,
            "completed_at": None,
            "due_date": task_data.get("due_date"),
            "progress": 0,
            "assignee": "小灵同学助理",
            "notes": [
                {
                    "time": datetime.now().strftime("%Y-%m-%d %H:%M"),
                    "content": "任务已创建，等待分配"
                }
            ]
        }
        
        # 添加到任务列表
        data["tasks"].append(task)
        
        # 更新统计
        data["stats"]["total"] += 1
        data["stats"]["todo"] += 1
        
        # 保存数据
        if TaskManager.save_tasks(data):
            # 更新看板文件
            TaskManager.update_kanban()
            return task_id
        return None
    
    @staticmethod
    def update_task(task_id, updates):
        """更新任务"""
        data = TaskManager.load_tasks()
        
        for i, task in enumerate(data["tasks"]):
            if task["id"] == task_id:
                # 记录状态变化
                old_status = task.get("status")
                new_status = updates.get("status")
                
                if old_status != new_status:
                    # 更新统计
                    if old_status == "todo":
                        data["stats"]["todo"] -= 1
                    elif old_status == "in_progress":
                        data["stats"]["in_progress"] -= 1
                    elif old_status == "done":
                        data["stats"]["done"] -= 1
                    
                    if new_status == "todo":
                        data["stats"]["todo"] += 1
                    elif new_status == "in_progress":
                        data["stats"]["in_progress"] += 1
                        if not task.get("started_at"):
                            task["started_at"] = datetime.now().strftime("%Y-%m-%d %H:%M")
                    elif new_status == "done":
                        data["stats"]["done"] += 1
                        task["completed_at"] = datetime.now().strftime("%Y-%m-%d %H:%M")
                        task["progress"] = 100
                
                # 更新任务字段
                for key, value in updates.items():
                    if key != "id":  # 不更新ID
                        task[key] = value
                
                # 添加更新记录
                if "notes" not in task:
                    task["notes"] = []
                
                update_note = {
                    "time": datetime.now().strftime("%Y-%m-%d %H:%M"),
                    "content": f"任务状态更新: {old_status} → {new_status}" if new_status else "任务信息已更新"
                }
                task["notes"].append(update_note)
                
                # 保存数据
                if TaskManager.save_tasks(data):
                    # 更新看板文件
                    TaskManager.update_kanban()
                    return True
                break
        
        return False
    
    @staticmethod
    def delete_task(task_id):
        """删除任务"""
        data = TaskManager.load_tasks()
        
        for i, task in enumerate(data["tasks"]):
            if task["id"] == task_id:
                # 更新统计
                status = task.get("status")
                if status == "todo":
                    data["stats"]["todo"] -= 1
                elif status == "in_progress":
                    data["stats"]["in_progress"] -= 1
                elif status == "done":
                    data["stats"]["done"] -= 1
                
                data["stats"]["total"] -= 1
                
                # 删除任务
                del data["tasks"][i]
                
                # 保存数据
                if TaskManager.save_tasks(data):
                    # 更新看板文件
                    TaskManager.update_kanban()
                    return True
                break
        
        return False
    
    @staticmethod
    def update_kanban():
        """更新看板文件"""
        try:
            data = TaskManager.load_tasks()
            
            # 读取现有看板内容
            if KANBAN_FILE.exists():
                with open(KANBAN_FILE, 'r', encoding='utf-8') as f:
                    content = f.read()
            else:
                content = "# 工作看板\n\n## 📋 任务概览\n\n"
            
            # 提取任务部分并更新
            lines = content.split('\n')
            new_lines = []
            in_task_section = False
            
            for line in lines:
                if line.startswith("#### **KB-"):
                    # 跳过旧的任务条目
                    continue
                elif line.startswith("### 🏆 本周完成"):
                    # 在任务部分后插入新任务
                    new_lines.append(line)
                    # 插入更新后的任务
                    new_lines.extend(TaskManager.generate_kanban_tasks(data))
                else:
                    new_lines.append(line)
            
            # 如果没有找到插入点，在末尾添加
            if "### 🏆 本周完成" not in content:
                new_lines.append("\n### 🏆 本周完成")
                new_lines.extend(TaskManager.generate_kanban_tasks(data))
            
            # 写入文件
            with open(KANBAN_FILE, 'w', encoding='utf-8') as f:
                f.write('\n'.join(new_lines))
            
            return True
        except Exception as e:
            print(f"更新看板文件错误: {e}")
            return False
    
    @staticmethod
    def generate_kanban_tasks(data):
        """生成看板任务条目"""
        lines = []
        
        # 按状态分组
        todo_tasks = [t for t in data["tasks"] if t["status"] == "todo"]
        in_progress_tasks = [t for t in data["tasks"] if t["status"] == "in_progress"]
        done_tasks = [t for t in data["tasks"] if t["status"] == "done"]
        
        # 待办任务
        if todo_tasks:
            lines.append(f"\n#### **待办任务 ({len(todo_tasks)})**")
            for task in todo_tasks[:5]:  # 只显示前5个
                lines.append(f"- **{task['id']}**: {task['description']}")
        
        # 进行中任务
        if in_progress_tasks:
            lines.append(f"\n#### **进行中任务 ({len(in_progress_tasks)})**")
            for task in in_progress_tasks:
                lines.append(f"- **{task['id']}**: {task['description']} - 进度: {task.get('progress', 0)}%")
        
        # 已完成任务
        if done_tasks:
            lines.append(f"\n#### **已完成任务 ({len(done_tasks)})**")
            for task in done_tasks[-5:]:  # 只显示最近5个
                lines.append(f"- ✅ **{task['id']}**: {task['description']}")
        
        return lines
    
    @staticmethod
    def get_recent_logs(limit=10):
        """获取最近的操作日志"""
        try:
            today = datetime.now().strftime("%Y-%m-%d")
            log_file = LOG_DIR / f"操作日志-{today}.md"
            
            if log_file.exists():
                with open(log_file, 'r', encoding='utf-8') as f:
                    lines = f.readlines()
                
                # 提取时间戳和内容
                logs = []
                for line in lines:
                    if line.strip().startswith("- "):
                        # 移除标记和空格
                        content = line.strip()[2:]
                        logs.append({
                            "time": datetime.now().strftime("%H:%M"),  # 简化时间
                            "content": content[:100] + "..." if len(content) > 100 else content
                        })
                
                return logs[-limit:]  # 返回最近的日志
            else:
                return []
        except Exception as e:
            print(f"读取日志错误: {e}")
            return []
    
    @staticmethod
    def get_system_status():
        """获取系统状态"""
        data = TaskManager.load_tasks()
        
        # 计算今日完成率
        today = datetime.now().strftime("%Y-%m-%d")
        today_tasks = [t for t in data["tasks"] 
                      if t.get("completed_at", "").startswith(today)]
        
        # 计算工作效率
        total_tasks = data["stats"]["total"]
        done_tasks = data["stats"]["done"]
        efficiency = (done_tasks / total_tasks * 100) if total_tasks > 0 else 0
        
        return {
            "online": True,
            "current_task": "开发看板控制中心 v1.0",
            "today_completed": len(today_tasks),
            "total_completed": done_tasks,
            "efficiency": round(efficiency, 1),
            "pending_actions": 1  # 等待用户指令
        }

# Flask路由
@app.route('/')
def index():
    """主控制面板"""
    return render_template('index.html')

@app.route('/api/status')
def get_status():
    """获取系统状态"""
    status = TaskManager.get_system_status()
    return jsonify(status)

@app.route('/api/tasks')
def get_tasks():
    """获取所有任务"""
    data = TaskManager.load_tasks()
    return jsonify(data)

@app.route('/api/tasks/<task_id>')
def get_task(task_id):
    """获取单个任务"""
    task = TaskManager.get_task_by_id(task_id)
    if task:
        return jsonify(task)
    return jsonify({"error": "任务不存在"}), 404

@app.route('/api/tasks', methods=['POST'])
def create_task():
    """创建新任务"""
    task_data = request.json
    if not task_data or 'description' not in task_data:
        return jsonify({"error": "缺少任务描述"}), 400
    
    task_id = TaskManager.add_task(task_data)
    if task_id:
        return jsonify({
            "success": True,
            "task_id": task_id,
            "message": "任务创建成功"
        })
    return jsonify({"error": "创建任务失败"}), 500

@app.route('/api/tasks/<task_id>', methods=['PUT'])
def update_task_route(task_id):
    """更新任务"""
    updates = request.json
    if not updates:
        return jsonify({"error": "缺少更新数据"}), 400
    
    success = TaskManager.update_task(task_id, updates)
    if success:
        return jsonify({"success": True, "message": "任务更新成功"})
    return jsonify({"error": "更新任务失败"}), 404

@app.route('/api/tasks/<task_id>', methods=['DELETE'])
def delete_task_route(task_id):
    """删除任务"""
    success = TaskManager.delete_task(task_id)
    if success:
        return jsonify({"success": True, "message": "任务删除成功"})
    return jsonify({"error": "删除任务失败"}), 404

@app.route('/api/logs')
def get_logs():
    """获取操作日志"""
    logs = TaskManager.get_recent_logs(limit=20)
    return jsonify(logs)

@app.route('/api/stats')
def get_stats():
    """获取统计信息"""
    data = TaskManager.load_tasks()
    return jsonify(data.get("stats", {}))

@app.route('/api/kanban/update', methods=['POST'])
def update_kanban_route():
    """手动更新看板"""
    success = TaskManager.update_kanban()
    if success:
        return jsonify({"success": True, "message": "看板更新成功"})
    return jsonify({"error": "更新看板失败"}), 500

# 静态文件路由
@app.route('/static/<path:filename>')
def static_files(filename):
    """提供静态文件"""
    return send_from_directory('static', filename)

def open_browser():
    """自动打开浏览器"""
    time.sleep(1.5)  # 等待服务器启动
    webbrowser.open('http://localhost:5000')

if __name__ == '__main__':
    print("🚀 启动小灵同学助理看板控制中心...")
    print("📊 版本: v1.0 基础版")
    print("🌐 访问地址: http://localhost:5000")
    print("🔄 自动打开浏览器中...")
    
    # 在后台线程中打开浏览器
    browser_thread = threading.Thread(target=open_browser)
    browser_thread.daemon = True
    browser_thread.start()
    
    # 启动Flask应用
    app.run(host='0.0.0.0', port=5000, debug=True, use_reloader=False)